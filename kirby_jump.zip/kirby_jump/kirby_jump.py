import pygame as pg
import random
from sys import exit
pg.init()

class Player:
    def __init__(self):
        self.x = 100
        self.y = 100
        self.hp = 3
        self.i_frames = 0
        self.skok = 0
        self.po = False
        self.pe = False
        self.image = pg.image.load("obrazki/kirby.png")
        self.w = self.image.get_width()
        self.h = self.image.get_height()
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
        self.ded = False
        self.quit = 150
    
    def move(self, keys):
        if self.pe == True:
            self.image = pg.image.load("obrazki/kirby_pe.png")
            self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
            
        if self.pe == False:
            self.po = False
            self.y+=4
            if keys[pg.K_SPACE]:
                self.skok=15
            if self.skok!=0:
                self.y-=8
                self.skok-=1

            if self.y < -50:
                self.y = 200

            if self.y > 530:
                self.y = 200
            
            self.image = pg.image.load("obrazki/kirby.png")
            self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
            
        if keys[pg.K_a]:
            self.image = pg.image.load("obrazki/kirby_po.png")
            self.po = True
            
            if self.hitbox.colliderect(pocisk.hitbox) and keys[pg.K_a]:
                self.pe = True
                self.image = pg.image.load("obrazki/kirby_pe.png")
                self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
            self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
        
        if self.pe == True:
            self. y += 1
            self.image = pg.image.load("obrazki/kirby_pe.png")
            self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
    
    def draw(self):
        screen.blit(self.image, (self.x, self.y))

    def hit(self,keys):
        if self.hitbox.colliderect(pocisk.hitbox):
            if self.i_frames == 0:
                self.hp -= 1 
                self.i_frames = 25
                if self.hp == 0:
                    self.ded = True

            else:
                self.i_frames -= 1

    def cast(self,keys):
        if self.pe == True and keys[pg.K_s]:
            gwiazdka.cast()
            pe = False
    
    def death(self):
        if self.ded == True:
            self.quit -= 1
            screen.blit(text_surface, (400,300))
        if self.quit == 0:
            exit()
            

class Pocisk:
    def __init__(self):
        self.speed = 0
        self.x = 400
        self.y = 300
        self.image = pg.image.load("obrazki/orzech.png")
        self.w = self.image.get_width()
        self.h = self.image.get_height()
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h) 
    
    def move(self):
        self.x -= 10
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
        if self.x <= -300:
            self.x = 900
            self.y = random.randint(0,500)
    
    def draw(self):
        screen.blit(self.image, (self.x, self.y))

class Gwiazdka:
    def __init__(self):
        self.speed = 0
        self.x = 400
        self.y = player.y
        self.image = pg.image.load("obrazki/gwiazdka.png")
        self.w = self.image.get_width()
        self.h = self.image.get_height()
        self.fly = False
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
    def cast(self):
        player.pe = False 
        self.fly = True
        self.x = player.x
        self.y = player.y
    def lot(self):
        if self.fly == True:
            screen.blit(self.image ,(self.x, self.y))
            self.x += 5
            if self.x > 1000:
                self.fly = False
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
class Drzewo:
    def __init__(self):
        self.x = 600
        self.y = 0
        self.surface = pg.Surface((600,800))
        self.h = 600
        self.w = 200
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
        self.hp = 3
        self.i_frames = 0
    def draw(self):
        if self.hp > 0:
            screen.blit(self.surface, (self.x, self.y))
    def hit(self):
        if self.hitbox.colliderect(gwiazdka.hitbox):
            if self.i_frames == 0:
                self.hp -= 1 
                self.i_frames = 75
            else:
                self.i_frames -= 1
        if self.hp == 0:
            screen.blit(text_surface,(400,300))
    
screen = pg.display.set_mode((800, 600)) 
pg.display.set_caption("nice_game")
clock = pg.time.Clock()
font = pg.font.Font(None, 100)


sky_surface = pg.image.load("obrazki/sky.jpg")
text_surface = font.render("YOU DIED", False, "red")
empty_heart_surface = pg.image.load("obrazki/empty_heart.png")
full_heart_surface = pg.image.load("obrazki/full_heart.png")
player = Player()
pocisk = Pocisk()
gwiazdka = Gwiazdka()
drzewo = Drzewo()
drzewo.surface.fill("gray")


while True:
    for event in pg.event.get():
        if event.type == pg.QUIT:
            pg.quit()
            exit()
    
    keys=pg.key.get_pressed()

    screen.blit(sky_surface, (0, 0))
    if player.ded == False:
        player.move(keys)
        player.draw()
        if player.po == False:    
            player.hit(keys)
        player.cast(keys)
    pocisk.move()
    pocisk.draw()
    gwiazdka.lot()
    drzewo.hit()
    drzewo.draw()
    player.death()

    if player.hp == 3:
        screen.blit(full_heart_surface, (750, 0))
        screen.blit(full_heart_surface, (700, 0))
        screen.blit(full_heart_surface, (650, 0))
    elif player.hp == 2:
        screen.blit(full_heart_surface, (750, 0))
        screen.blit(full_heart_surface, (700, 0))
        screen.blit(empty_heart_surface, (650, 0))
    elif player.hp == 1:
        screen.blit(full_heart_surface, (750, 0))
        screen.blit(empty_heart_surface, (700, 0))
        screen.blit(empty_heart_surface, (650, 0))
    if player.hp == 0:
        screen.blit(empty_heart_surface, (750, 0))
        screen.blit(empty_heart_surface, (700, 0))
        screen.blit(empty_heart_surface, (650, 0))

    pg.display.update()
    clock.tick(50)