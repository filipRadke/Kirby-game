import pygame as pg
import random
from sys import exit
import time

pg.init()
screen = pg.display.set_mode((800, 600)) 
pg.display.set_caption("nice_game")
clock = pg.time.Clock()
font = pg.font.Font(None, 100)

trud = 0
poziom = True
wybor = pg.Surface((800,600))
wybor.fill("black")
p1 = pg.Surface((100,100))
p2 = pg.Surface((100,100))
p3 = pg.Surface((100,100))
p1.fill("green")
p2.fill("yellow")
p3.fill("red")

class Player:
    def __init__(self):
        self.x = 100
        self.y = 100
        self.hp = 3
        self.i_frames = 0
        self.skok = 0
        self.po = False
        self.pe = False
        self.image = pg.image.load("obrazki/kirby.png")
        self.w = self.image.get_width()
        self.h = self.image.get_height()
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
        self.ded = False
        self.quit = 150
    
    def move(self, keys):
        if self.pe == True:
            self.image = pg.image.load("obrazki/kirby3.png")
            self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
            
        if self.pe == False:
            self.po = False
            self.y+=4
            if keys[pg.K_SPACE]:
                self.skok=15
            if self.skok!=0:
                self.y-=8
                self.skok-=1

            if self.y < -50:
                self.y = 200

            if self.y > 530:
                self.y = 200
            
            self.image = pg.image.load("obrazki/kirby.png")
            self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
            
        if keys[pg.K_a]:
            self.image = pg.image.load("obrazki/kirby1.png")
            self.po = True
            
            if self.hitbox.colliderect(pocisk.hitbox) and keys[pg.K_a]:
                self.pe = True
                self.image = pg.image.load("obrazki/kirby3.png")
                self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
            self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
        
        if self.pe == True:
            self. y += 1
            self.image = pg.image.load("obrazki/kirby3.png")
            self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
    
    def draw(self):
        screen.blit(self.image, (self.x, self.y))
        if self.hp > 3:
            self.hp = 3

    def hit(self,keys):
        if self.hitbox.colliderect(pocisk.hitbox or kamien.hitbox):
            if self.i_frames == 0:
                self.hp -= 1 
                self.i_frames = 25
                if self.hp == 0:
                    self.ded = True

            else:
                self.i_frames -= 1
    
    def hroot(self,keys):
        if self.hitbox.colliderect(korzen.hitbox):
            if self.i_frames == 0:
                self.hp -= 1 
                self.i_frames = 25
                if self.hp == 0:
                    self.ded = True

            else:
                self.i_frames -= 1

    def hkamien(self,keys):
        if self.hitbox.colliderect(kamien.hitbox):
            if self.i_frames == 0:
                self.hp -= 1 
                self.i_frames = 25
                if self.hp == 0:
                    self.ded = True

            else:
                self.i_frames -= 1

    def heal(self,keys):
        if self.hitbox.colliderect(jablko.hitbox) and self.po == True:
            if self.i_frames == 0:
                self.hp += 1 
                self.i_frames = 25
                if self.hp == 0:
                    self.ded = True

            else:
                self.i_frames -= 1    
                

    def cast(self,keys):
        if self.pe == True and keys[pg.K_s]:
            gwiazdka.cast()
            pe = False
    
    def death(self):
        if self.ded == True:
            self.quit -= 1
            screen.blit(text_surface, (400,300))
        if self.quit == 0:
            exit()
            

class Pocisk:
    def __init__(self):
        self.x = 400
        self.y = 300
        self.image = pg.image.load("obrazki/orzech.png")
        self.w = self.image.get_width()
        self.h = self.image.get_height()
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h) 
    
    def move(self,los,trud):
        self.x -= trud * 2
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
        if self.x <= -300 and los == 1:
            self.x = 900
            self.y = random.randint(0,500)
    
    def draw(self):
        screen.blit(self.image, (self.x, self.y))

class Jablko:
    def __init__(self):
        self.x = 400
        self.y = 300
        self.image = pg.image.load("obrazki/fire_ball.png")
        self.w = self.image.get_width()
        self.h = self.image.get_height()
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
    
    def move(self,los,trud):
        self.x -= trud * 2
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
        if self.x <= -300 and los == 2:
            self.x = 900
            self.y = random.randint(0,500)

    def draw(self):
        screen.blit(self.image, (self.x, self.y))
    
    def draw(self):
        screen.blit(self.image, (self.x, self.y))


class Gwiazdka:
    def __init__(self):
        self.speed = 0
        self.x = 400
        self.y = player.y
        self.image = pg.image.load("obrazki/gwiazdka.png")
        self.w = self.image.get_width()
        self.h = self.image.get_height()
        self.fly = False
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
    def cast(self):
        player.pe = False 
        self.fly = True
        self.x = player.x
        self.y = player.y
    def lot(self,trud):
        if self.fly == True:
            screen.blit(self.image ,(self.x, self.y))
            self.x += trud
            if self.x > 1000:
                self.fly = False
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
class Drzewo:
    def __init__(self):
        self.x = 600
        self.y = 0
        self.surface = pg.Surface((600,800))
        self.h = 600
        self.w = 200
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
        self.hp = 3
        self.i_frames = 0
    def draw(self):
        if self.hp > 0:
            screen.blit(self.surface, (self.x, self.y))
    def hit(self):
        if self.hitbox.colliderect(gwiazdka.hitbox):
            if self.i_frames == 0:
                self.hp -= 1 
                self.i_frames = 75
            else:
                self.i_frames -= 1
        if self.hp == 0:
            screen.blit(win_surface,(400,300))

class Korzen:
    def __init__(self):
        self.x = 100
        self.y = 650
        self.image = pg.image.load("obrazki/root.png")
        self.h = self.image.get_height()
        self.w = self.image.get_width()
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
    def cast(self,gd,kg):
        if gd == 199 and kg == 1:
            self.y = 325
        if gd == 249:
            self.y = 650
    def draw(self):
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
        screen.blit(self.image, (self.x, self.y))

class Kamien:
    def __init__(self):
        self.x = 400
        self.y = 300
        self.image = pg.image.load("obrazki/kamyk.png")
        self.w = self.image.get_width()
        self.h = self.image.get_height()
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h) 
    
    def move(self,los,trud):
        self.x -= trud * 2
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
        if self.x <= -300 and los != (1 and 2):
            self.x = 900
            self.y = random.randint(0,500)
    
    def draw(self):
        screen.blit(self.image, (self.x, self.y))

sky_surface = pg.image.load("obrazki/sky.jpg")
text_surface = font.render("YOU DIED", False, "red")
win_surface = font.render("YOU WON", False, "green")
empty_heart_surface = pg.image.load("obrazki/empty_heart.png")
full_heart_surface = pg.image.load("obrazki/full_heart.png")
nuts_surface = pg.image.load("obrazki/nuts.png")

screen.blit(nuts_surface,(0,0))
pg.display.update()
trud = int(input("poznom trudnosci bo gowno nie dziala "))

player = Player()
pocisk = Pocisk()
gwiazdka = Gwiazdka()
drzewo = Drzewo()
jablko = Jablko()
drzewo.surface.fill("gray")
korzen = Korzen()
kamien = Kamien()
gd = 0
kg = 0
x = 0
los = 1

while True:
    screen.fill("black")

    while True:
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                exit()
        if x == 90:
            los = random.randint(1,3)
            x = 0
        else:
            x += 1

        
        keys=pg.key.get_pressed()

        if gd < 250:
            gd += 1
        else:
            gd = 0 
        if gd == 198:
            kg = random.randint(1,1)

        screen.blit(sky_surface, (0, 0))
        if player.ded == False:
            player.move(keys)
            player.draw()
            player.heal(keys)
            if player.po == False:
                player.hit(keys)
                player.hroot(keys)
                player.hkamien(keys)
            player.cast(keys)
        pocisk.move(los,trud)
        pocisk.draw()
        jablko.move(los,trud)
        jablko.draw()
        kamien.move(los,trud)
        kamien.draw()
        gwiazdka.lot(trud)
        drzewo.hit()
        drzewo.draw()
        korzen.cast(gd,kg)
        korzen.draw()
        player.death()

        if player.hp == 3:
            screen.blit(full_heart_surface, (500, 0))
            screen.blit(full_heart_surface, (600, 0))
            screen.blit(full_heart_surface, (700, 0))
        elif player.hp == 2:
            screen.blit(empty_heart_surface, (500, 0))
            screen.blit(full_heart_surface, (600, 0))
            screen.blit(full_heart_surface, (700, 0))
        elif player.hp == 1:
            screen.blit(empty_heart_surface, (500, 0))
            screen.blit(empty_heart_surface, (600, 0))
            screen.blit(full_heart_surface, (700, 0))
        if player.hp == 0:
            screen.blit(empty_heart_surface, (500, 0))
            screen.blit(empty_heart_surface, (600, 0))
            screen.blit(empty_heart_surface, (700, 0))

        pg.display.update()
        clock.tick(50)