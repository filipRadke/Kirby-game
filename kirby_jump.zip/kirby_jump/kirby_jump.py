import pygame as pg
import random
from sys import exit
pg.init()

class Player:
    def __init__(self):
        self.x = 100
        self.y = 100
        self.hp = 3
        self.i_frames = 0
        self.skok = 0
        self.image = pg.image.load("obrazki/kirby.png")
        self.w = self.image.get_width()
        self.h = self.image.get_height()
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
    def move(self, keys):
        self.y+=4
        if keys[pg.K_SPACE]:
            self.skok=15
        if self.skok!=0:
            self.y-=8
            self.skok-=1

        if self.y < 8:
            self.y = 11
        if self.y > 470:
            self.y = 467
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)

    def draw(self):
        screen.blit(self.image, (self.x, self.y))

class Pocisk:
    def __init__(self):
        self.speed = 0
        self.x = 400
        self.y = 300
        self.image = pg.image.load("obrazki/fire_ball.png")
        self.w = self.image.get_width()
        self.h = self.image.get_height()
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h) 
    def move(self):
            self.x -= 5
            self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
            if self.x <= -300:
                self.x = 900
                self.y = random.randint(0,0)
    def draw(self):
        screen.blit(self.image, (self.x, self.y))

screen = pg.display.set_mode((800, 600)) 
pg.display.set_caption("nice_game")
clock = pg.time.Clock()
font = pg.font.Font(None, 30)


sky_surface = pg.image.load("obrazki/sky.jpg")
text_surface = font.render("KIRBO", False, "hotpink")
empty_heart_surface = pg.image.load("obrazki/empty_heart.png")
full_heart_surface = pg.image.load("obrazki/full_heart.png")
player = Player()
pocisk = Pocisk()

while True:
    for event in pg.event.get():
        if event.type == pg.QUIT:
            pg.quit()
            exit()
    
    mpos=pg.mouse.get_pos()
    pg.mouse.set_visible(False)
    keys=pg.key.get_pressed()

    screen.blit(sky_surface, (0, 0))
    screen.blit(text_surface, mpos)

    if player.hitbox.colliderect(pocisk.hitbox):
            if player.i_frames == 0:
                player.hp -= 1
                player.i_frames = 75
                if player.hp == 0:
                    exit()

    if player.i_frames != 0:
        player.i_frames -= 1 

    if player.hp == 3:
        screen.blit(full_heart_surface, (750, 0))
        screen.blit(full_heart_surface, (700, 0))
        screen.blit(full_heart_surface, (650, 0))
    elif player.hp == 2:
        screen.blit(full_heart_surface, (750, 0))
        screen.blit(full_heart_surface, (700, 0))
        screen.blit(empty_heart_surface, (650, 0))
    elif player.hp == 1:
        screen.blit(full_heart_surface, (750, 0))
        screen.blit(empty_heart_surface, (700, 0))
        screen.blit(empty_heart_surface, (650, 0))
    if player.hp == 0:
        screen.blit(empty_heart_surface, (750, 0))
        screen.blit(empty_heart_surface, (700, 0))
        screen.blit(empty_heart_surface, (650, 0))

    player.move(keys)
    player.draw()
    pocisk.move()
    pocisk.draw()

    pg.display.update()
    clock.tick(50)