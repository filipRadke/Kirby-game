import pygame as pg
import random
from sys import exit
import time

pg.init()
screen = pg.display.set_mode((800, 600)) 
pg.display.set_caption("nice_game")
clock = pg.time.Clock()
font = pg.font.Font(None, 65)

trud = 0
poziom = True
wybor = pg.Surface((800,600))
wybor.fill("black")
p1 = pg.Surface((100,100))
p2 = pg.Surface((100,100))
p3 = pg.Surface((100,100))
p1.fill("green")
p2.fill("yellow")
p3.fill("red")

class Player:
    def __init__(self):
        self.x = 100
        self.y = 100
        self.hp = 3
        self.i_frames = 0
        self.skok = 0
        self.po = False
        self.pe = False
        self.image = pg.image.load("obrazki/kirby.png")
        self.w = self.image.get_width()
        self.h = self.image.get_height()
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
        self.ded = False
        self.quit = 250
        self.leczony = -1
    def move(self, keys):
        if self.pe == True:
            self.image = pg.image.load("obrazki/kirby3.png")
            self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)   
        if self.pe == False:
            self.po = False
            self.y+=6
            
            if keys[pg.K_SPACE]:
                self.skok=15
            if self.skok!=0:
                self.y-=12
                self.skok-=1
            if self.y < -50:
                self.y = 200
            if self.y > 530:
                self.y = 200
            
            self.image = pg.image.load("obrazki/kirby.png")
            self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)          
        if keys[pg.K_a]:
            self.image = pg.image.load("obrazki/kirby1.png")
            self.po = True
            
            if self.hitbox.colliderect(pocisk.hitbox) and keys[pg.K_a]:
                self.pe = True
                self.image = pg.image.load("obrazki/kirby3.png")
                self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
            self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
        
        if self.pe == True:
            self. y += 1
            self.image = pg.image.load("obrazki/kirby3.png")
            self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
    def draw(self):
        if self.i_frames > 0:
            self.image = pg.image.load("obrazki/kirby4.png")
        screen.blit(self.image, (self.x, self.y))
        if self.hp > 3:
            self.hp = 3
    def hit(self,keys):
        if self.hitbox.colliderect(pocisk.hitbox):
            if self.i_frames < 0:
                self.hp -= 1 
                self.i_frames = 30
                if self.hp == 0:
                    self.ded = True
        if self.hitbox.colliderect(kamien.hitbox):
            if self.i_frames < 0:
                self.hp -= 1 
                self.i_frames = 30
                if self.hp == 0:
                    self.ded = True
        if self.hitbox.colliderect(korzen.hitbox):
            if self.i_frames < 0:
                self.hp -= 1 
                self.i_frames = 30
                if self.hp == 0:
                    self.ded = True
        self.i_frames -= 1
    def heal(self,keys):
        if self.hitbox.colliderect(jablko.hitbox) and self.po == True and self.leczony <=0:
            self.hp += 1 
            self.leczony = 50
            if self.hp == 0:
                self.ded = True
        else:
            self.leczony -= 1
    def cast(self,keys):
        if self.pe == True and keys[pg.K_s]:
            gwiazdka.cast()
            pe = False
    def death(self):
        if self.ded == True:
            self.quit -= 1
            screen.blit(text_surface, (400,300))
        if self.quit == 0:
            exit()
            

class Pocisk:
    def __init__(self):
        self.x = 400
        self.y = 300
        self.image = pg.image.load("obrazki/orzech.png")
        self.w = self.image.get_width()
        self.h = self.image.get_height()
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h) 
    
    def move(self,los,trud):
        self.x -= trud * 2
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
        if self.x <= -300 and los == 1:
            self.x = 900
            self.y = random.randint(0,500)
    
    def draw(self):
        screen.blit(self.image, (self.x, self.y))

class Jablko:
    def __init__(self):
        self.x = 400
        self.y = 300
        self.image = pg.image.load("obrazki/apple.png")
        self.w = self.image.get_width()
        self.h = self.image.get_height()
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
    
    def move(self,los,trud):
        self.x -= trud * 2
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
        if self.x <= -300 and los == 2:
            self.x = 900
            self.y = random.randint(0,500)

    def draw(self):
        screen.blit(self.image, (self.x, self.y))
    
    def draw(self):
        screen.blit(self.image, (self.x, self.y))


class Gwiazdka:
    def __init__(self):
        self.speed = 0
        self.x = 900
        self.y = 700
        self.image = pg.image.load("obrazki/gwiazdka.png")
        self.w = self.image.get_width()
        self.h = self.image.get_height()
        self.fly = False
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
    def cast(self):
        if self.x >= 600:
            player.pe = False 
            self.fly = True
            self.x = player.x
            self.y = player.y
    def lot(self,trud):
        if self.fly == True:
            screen.blit(self.image ,(self.x, self.y))
            self.x += 5
            if self.x > 1000:
                self.fly = False
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
class Drzewo:
    def __init__(self):
        self.x = 0
        self.y = 0
        self.surface = pg.image.load("obrazki/Woods.png")
        self.hitbox = pg.Rect(650, 0, 150, 600)
        self.hp = 3
        self.i_frames = 0
    def draw(self):
        screen.blit(self.surface, (self.x, self.y))
    def hit(self):
        if self.hitbox.colliderect(gwiazdka.hitbox):
            if self.i_frames <= 0:
                self.hp -= 1 
                self.i_frames = 75
        else:
            self.i_frames -= 1
        if self.hp <= 0:
            self.surface = pg.image.load("obrazki/Woods1.png")

class Korzen:
    def __init__(self):
        self.x = 100
        self.y = 650
        self.image = pg.image.load("obrazki/root.png")
        self.h = self.image.get_height()
        self.w = self.image.get_width()
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
    def cast(self,gd,kg):
        if gd == 199 and kg == 1:
            self.image = pg.image.load("obrazki/root.png")
            self.h = self.image.get_height()
            self.y = 325
        if gd == 199 and kg == 2:
            self.image = pg.image.load("obrazki/branch.png")
            self.h = self.image.get_height()
            self.y = 0
        if gd == 229:
            self.y = 650
    def draw(self):
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
        screen.blit(self.image, (self.x, self.y))

class Kamien:
    def __init__(self):
        self.x = 400
        self.y = 300
        self.image = pg.image.load("obrazki/kamyk.png")
        self.w = self.image.get_width()
        self.h = self.image.get_height()
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h) 
    
    def move(self,los,trud):
        self.x -= trud * 2
        self.hitbox = pg.Rect(self.x, self.y, self.w, self.h)
        if self.x <= -300 and los != (1 and 2):
            self.x = 900
            self.y = random.randint(0,500)
    
    def draw(self):
        screen.blit(self.image, (self.x, self.y))

class Lisc:
    def __init__(self):
        self.x = 100
        self.y = -100
        self.image = pg.image.load("obrazki/lisc.png")
    def rusz(self,gd,kg):
        if gd == 169 and kg == 2:
            self.y = 0
        if gd == 169 and kg == 1:
            self.y = 550
        if gd == 198:
            self.y = 650
    def draw(self):
        screen.blit(self.image, (self.x, self.y))


sky_surface = pg.image.load("obrazki/sky.jpg")
text_surface = font.render("YOU DIED", False, "red")
win_surface = font.render("YOU WON", False, "green")
empty_heart_surface = pg.image.load("obrazki/empty_heart.png")
full_heart_surface = pg.image.load("obrazki/full_heart.png")
heal_heart_surface = pg.image.load("obrazki/heal_heart.png")
nuts_surface = pg.image.load("obrazki/nuts.png")

screen.blit(nuts_surface,(0,0))
pg.display.update()
trud = int(input("Wybierz poziom trudnosci(od 1 do 10): "))

if trud < 1 or trud > 10:
    print("You stupid")
    time.sleep(5)
    exit()
time.sleep(5)

player = Player()
pocisk = Pocisk()
gwiazdka = Gwiazdka()
drzewo = Drzewo()
jablko = Jablko()
korzen = Korzen()
kamien = Kamien()
lisc = Lisc()
gd = 0
kg = 0
x = 0
los = 1
death_surface = pg.image.load("obrazki/end_screen.png")
leaf_surface = pg.image.load("obrazki/wwww.png")
dim_surface = pg.Surface((800,600))
dim_surface.set_alpha(255)
ciemnosc = 255
kirby_win = pg.image.load("obrazki/win.png")
text_surface = font.render("Kirby took deez nuts",True,"black")

while True:
    screen.fill("black")

    while True:
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                exit()

        if x == 90:
            los = random.randint(1,3)
            x = 0
        else:
            x += 1

        keys=pg.key.get_pressed()

        if gd < 250:
            gd += 1
        else:
            gd = 0 
        if gd == 168:
            kg = random.randint(1,2)

        screen.blit(sky_surface, (0, 0))
        drzewo.hit()
        drzewo.draw()
        if player.ded == False:
            player.move(keys)
            player.heal(keys)
            if player.po == False:
                player.hit(keys)
            player.cast(keys)
            player.draw()
        pocisk.move(los,trud)
        pocisk.draw()
        jablko.move(los,trud)
        jablko.draw()
        kamien.move(los,trud)
        kamien.draw()
        gwiazdka.lot(trud)
        lisc.rusz(gd,kg)
        lisc.draw()
        korzen.cast(gd,kg)
        korzen.draw()
        player.death()
        if player.hp == 3 and player.leczony >= 0:
            screen.blit(heal_heart_surface, (500, 0))
            screen.blit(full_heart_surface, (600, 0))
            screen.blit(full_heart_surface, (700, 0))
        elif player.hp == 2  and player.leczony >= 0:
            screen.blit(empty_heart_surface, (500, 0))
            screen.blit(heal_heart_surface, (600, 0))
            screen.blit(full_heart_surface, (700, 0))
        elif player.hp == 3 and player.leczony <= 0:
            screen.blit(full_heart_surface, (500, 0))
            screen.blit(full_heart_surface, (600, 0))
            screen.blit(full_heart_surface, (700, 0))
        elif player.hp == 2 and player.leczony <= 0:
            screen.blit(empty_heart_surface, (500, 0))
            screen.blit(full_heart_surface, (600, 0))
            screen.blit(full_heart_surface, (700, 0))
        elif player.hp == 1 and player.leczony <= 0:
            screen.blit(empty_heart_surface, (500, 0))
            screen.blit(empty_heart_surface, (600, 0))
            screen.blit(full_heart_surface, (700, 0))
        if player.hp == 0  and player.leczony <= 0:
            screen.blit(empty_heart_surface, (500, 0))
            screen.blit(empty_heart_surface, (600, 0))
            screen.blit(empty_heart_surface, (700, 0))

        if player.ded == True:
            screen.blit(death_surface,(0,0))
            screen.blit(dim_surface,(0,0))
            ciemnosc -= 4
            dim_surface.set_alpha(ciemnosc)
        if drzewo.hp <= 0:
            screen.blit(sky_surface,(0,0))
            drzewo.draw()
            screen.blit(kirby_win,(350,250))
            screen.blit(text_surface,(200,475))

        pg.display.update()
        clock.tick(50)